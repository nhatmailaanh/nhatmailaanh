import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AIRepairResponse, AIScriptResponse, AITrainingResponse } from "../types";

// In a real app, use process.env.API_KEY.
// For this demo, we assume the environment variable is injected or managed by the platform.
const apiKey = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey });

const MODEL_ID = 'gemini-2.5-flash';

// Schemas
const scriptSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    blocks: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          durationMinutes: { type: Type.NUMBER },
          talkingPoints: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          forbiddenCategoryIds: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Suggested forbidden category IDs (e.g. CAT_01) relevant to this block."
          }
        },
        required: ["title", "durationMinutes", "talkingPoints", "forbiddenCategoryIds"]
      }
    }
  },
  required: ["blocks"]
};

const repairSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    onAirFixScript: { type: Type.STRING, description: "A short sentence the host can say immediately to correct the mistake." },
    noteForTraining: { type: Type.STRING, description: "Brief explanation of why this was a violation." }
  },
  required: ["onAirFixScript", "noteForTraining"]
};

const trainingSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    recommendations: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of 3-5 specific training recommendations."
    }
  },
  required: ["recommendations"]
};

export const generateLiveScript = async (
  project: string,
  market: string,
  type: string,
  duration: number,
  objective: string
): Promise<AIScriptResponse> => {
  try {
    const prompt = `
      Create a TikTok Live script outline for a real estate project.
      Project Name: ${project}
      Market: ${market}
      Property Type: ${type}
      Total Duration: ${duration} minutes
      Objective: ${objective}
      
      Split the session into logical blocks (Intro, Project Details, Legal, Pricing/Offer, Q&A, Outro).
      For 'forbiddenCategoryIds', select from: CAT_01, CAT_02, CAT_03, CAT_04, CAT_05, CAT_06, CAT_07, CAT_08 based on where risk is highest in that block.
      Language: Vietnamese.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_ID,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: scriptSchema,
        temperature: 0.7
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIScriptResponse;
    }
    throw new Error("Empty response from AI");
  } catch (error) {
    console.error("Gemini Script Gen Error:", error);
    // Fallback if AI fails
    return {
      blocks: [
        { title: "Giới thiệu", durationMinutes: 5, talkingPoints: ["Chào mừng", "Giới thiệu chủ đề"], forbiddenCategoryIds: [] }
      ]
    };
  }
};

export const generateViolationRepair = async (
  categoryName: string,
  severity: string,
  context: string
): Promise<AIRepairResponse> => {
  try {
    const prompt = `
      A real estate host just committed a violation during a TikTok Live.
      Violation Category: ${categoryName}
      Severity: ${severity}
      Context/User Note: ${context || "N/A"}
      
      Provide a "quick fix" script (Vietnamese) for the host to say immediately to mitigate the risk without killing the vibe.
      Also provide a short training note.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_ID,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: repairSchema,
        temperature: 0.5
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AIRepairResponse;
    }
    throw new Error("Empty repair response");
  } catch (error) {
    console.error("Gemini Repair Error:", error);
    return {
      onAirFixScript: "Xin lỗi quý vị, tôi xin đính chính lại thông tin vừa rồi...",
      noteForTraining: "Lỗi hệ thống AI, vui lòng kiểm tra lại thủ công."
    };
  }
};

export const generateTrainingRecommendations = async (
  violationSummary: string
): Promise<AITrainingResponse> => {
  try {
    const prompt = `
      Analyze these violations from a Real Estate TikTok Live session and suggest 3-5 specific training improvements for the sales team.
      Violation Data: ${violationSummary}
      Language: Vietnamese.
    `;

    const response = await ai.models.generateContent({
      model: MODEL_ID,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: trainingSchema,
        temperature: 0.7
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as AITrainingResponse;
    }
    throw new Error("Empty training response");
  } catch (error) {
    console.error("Gemini Training Error:", error);
    return { recommendations: ["Tập trung học lại bộ quy tắc cộng đồng TikTok", "Tránh cam kết lợi nhuận quá đà"] };
  }
};
