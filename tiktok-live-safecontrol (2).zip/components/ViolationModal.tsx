import React, { useState } from 'react';
import { FORBIDDEN_CATEGORIES } from '../constants';
import { RiskLevel, Severity, UserRole, Violation } from '../types';
import { generateViolationRepair } from '../services/geminiService';

interface Props {
  sessionId: string;
  blockId: string | undefined;
  onSave: (v: Violation) => void;
  onClose: () => void;
}

const ViolationModal: React.FC<Props> = ({ sessionId, blockId, onSave, onClose }) => {
  const [categoryId, setCategoryId] = useState(FORBIDDEN_CATEGORIES[0].id);
  const [severity, setSeverity] = useState<Severity>(Severity.LIGHT);
  const [speakerRole, setSpeakerRole] = useState<UserRole>(UserRole.HOST);
  const [note, setNote] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [aiResult, setAiResult] = useState<{fix: string, training: string} | null>(null);

  const handleSubmit = async () => {
    setIsProcessing(true);
    const category = FORBIDDEN_CATEGORIES.find(c => c.id === categoryId);
    
    // Call AI for repair suggestion
    const aiResponse = await generateViolationRepair(
      category?.name || "Unknown",
      severity,
      note
    );

    setAiResult({
      fix: aiResponse.onAirFixScript,
      training: aiResponse.noteForTraining
    });
    setIsProcessing(false);
  };

  const handleFinalConfirm = () => {
    if (!aiResult) return;
    
    const violation: Violation = {
      id: `viol-${Date.now()}`,
      liveSessionId: sessionId,
      scriptBlockId: blockId,
      timestamp: new Date().toISOString(),
      timestampInSeconds: 0, // In real app, calculate offset from session start
      speakerRole,
      categoryId,
      severity,
      note,
      aiRepairSuggestion: aiResult.fix,
      aiTrainingNote: aiResult.training
    };

    onSave(violation);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="bg-red-600 px-6 py-4 flex justify-between items-center">
          <h2 className="text-white font-bold text-lg flex items-center">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            Báo cáo Vi phạm
          </h2>
          <button onClick={onClose} className="text-red-100 hover:text-white">✕</button>
        </div>

        {!aiResult ? (
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Loại vi phạm</label>
              <select 
                className="w-full border border-gray-300 rounded-md p-2"
                value={categoryId}
                onChange={e => setCategoryId(e.target.value)}
              >
                {FORBIDDEN_CATEGORIES.map(c => (
                  <option key={c.id} value={c.id}>
                    [{c.riskLevel}] {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Mức độ</label>
                <select 
                  className="w-full border border-gray-300 rounded-md p-2"
                  value={severity}
                  onChange={e => setSeverity(e.target.value as Severity)}
                >
                  <option value={Severity.LIGHT}>Nhẹ (Light)</option>
                  <option value={Severity.MEDIUM}>Trung bình (Medium)</option>
                  <option value={Severity.SEVERE}>Nghiêm trọng (Severe)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Người nói</label>
                <select 
                  className="w-full border border-gray-300 rounded-md p-2"
                  value={speakerRole}
                  onChange={e => setSpeakerRole(e.target.value as UserRole)}
                >
                  <option value={UserRole.HOST}>Host</option>
                  <option value={UserRole.MOD}>Khách mời / Mod</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ghi chú / Ngữ cảnh (Để AI sửa lỗi)</label>
              <textarea 
                className="w-full border border-gray-300 rounded-md p-2 h-20"
                placeholder="Ví dụ: Host vừa cam kết lợi nhuận 30%/năm..."
                value={note}
                onChange={e => setNote(e.target.value)}
              />
            </div>

            <button 
              onClick={handleSubmit}
              disabled={isProcessing}
              className="w-full bg-red-600 text-white py-2 rounded-lg font-semibold hover:bg-red-700 transition flex justify-center items-center"
            >
              {isProcessing ? "AI đang phân tích..." : "Xử lý & Nhận hướng dẫn sửa lỗi"}
            </button>
          </div>
        ) : (
          <div className="p-6 space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h3 className="text-green-800 font-bold text-sm uppercase mb-2">Lời thoại sửa lỗi (On-Air Fix)</h3>
              <p className="text-gray-800 text-lg font-medium italic">"{aiResult.fix}"</p>
            </div>

             <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
              <h3 className="text-gray-600 font-bold text-xs uppercase mb-1">Ghi chú Training</h3>
              <p className="text-gray-700 text-sm">{aiResult.training}</p>
            </div>

            <div className="flex gap-3 mt-4">
              <button 
                onClick={() => setAiResult(null)}
                className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200"
              >
                Quay lại
              </button>
              <button 
                onClick={handleFinalConfirm}
                className="flex-1 bg-red-600 text-white py-2 rounded-lg font-medium hover:bg-red-700"
              >
                Xác nhận & Lưu Log
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViolationModal;
