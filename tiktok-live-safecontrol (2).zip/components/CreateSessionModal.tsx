import React, { useState } from 'react';
import { MARKETS, OBJECTIVES, PROPERTY_TYPES, MOCK_USERS, PREBUILT_TEMPLATES } from '../constants';
import { useAppContext } from '../AppContext';
import { LiveSession, ScriptBlock, SessionStatus, UserRole } from '../types';
import { generateLiveScript } from '../services/geminiService';

interface Props {
  onClose: () => void;
}

const CreateSessionModal: React.FC<Props> = ({ onClose }) => {
  const { addSession } = useAppContext();
  const [formData, setFormData] = useState({
    projectName: '',
    market: MARKETS[0],
    propertyType: PROPERTY_TYPES[0],
    durationMinutes: 60,
    objective: OBJECTIVES[0],
    hostId: '',
    moderatorIds: [] as string[]
  });
  
  // New State for Script Source
  const [scriptSource, setScriptSource] = useState<'AI' | 'TEMPLATE'>('AI');
  const [selectedTemplateId, setSelectedTemplateId] = useState(PREBUILT_TEMPLATES[0].id);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedBlocks, setGeneratedBlocks] = useState<ScriptBlock[]>([]);
  const [step, setStep] = useState<1 | 2>(1);

  const hosts = MOCK_USERS.filter(u => u.role === UserRole.HOST);
  const mods = MOCK_USERS.filter(u => u.role === UserRole.MOD);

  const handleGenerateScript = async () => {
    if (!formData.projectName || !formData.hostId) {
      alert("Vui lòng nhập tên dự án và chọn Host.");
      return;
    }

    if (scriptSource === 'TEMPLATE') {
      // Load Pre-built Template
      const template = PREBUILT_TEMPLATES.find(t => t.id === selectedTemplateId);
      if (template) {
        const blocksWithIds: ScriptBlock[] = template.blocks.map((b, idx) => ({
          ...b,
          id: `block-tpl-${Date.now()}-${idx}`,
          liveSessionId: '',
          order: idx
        }));
        
        // Auto-fill some form data based on template
        setFormData(prev => ({
          ...prev,
          durationMinutes: template.defaultDuration,
          propertyType: template.propertyType || prev.propertyType,
          objective: template.objective || prev.objective
        }));

        setGeneratedBlocks(blocksWithIds);
        setStep(2);
      }
      return;
    }
    
    // AI Generation Logic
    setIsGenerating(true);
    try {
      const result = await generateLiveScript(
        formData.projectName,
        formData.market,
        formData.propertyType,
        formData.durationMinutes,
        formData.objective
      );
      
      const blocksWithIds: ScriptBlock[] = result.blocks.map((b, idx) => ({
        ...b,
        id: `block-${Date.now()}-${idx}`,
        liveSessionId: '', // Set later
        order: idx
      }));

      setGeneratedBlocks(blocksWithIds);
      setStep(2);
    } catch (e) {
      alert("Lỗi khi tạo kịch bản AI. Vui lòng thử lại.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    const newSession: LiveSession = {
      id: `session-${Date.now()}`,
      ...formData,
      status: SessionStatus.PLANNED,
      blocks: generatedBlocks,
      violations: [],
      safetyScore: 100
    };
    // Assign session ID to blocks
    newSession.blocks = newSession.blocks.map(b => ({ ...b, liveSessionId: newSession.id }));
    
    addSession(newSession);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h2 className="text-xl font-bold text-gray-800">
            {step === 1 ? "Thiết lập Phiên Live" : "Review Kịch bản"}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1">
          {step === 1 ? (
            <div className="space-y-5">
              
              {/* Basic Info */}
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tên dự án</label>
                  <input 
                    type="text" 
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
                    value={formData.projectName}
                    onChange={e => setFormData({...formData, projectName: e.target.value})}
                    placeholder="Ví dụ: Vinhomes Ocean Park 2"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Thị trường</label>
                    <select 
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      value={formData.market}
                      onChange={e => setFormData({...formData, market: e.target.value})}
                    >
                      {MARKETS.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Host chính</label>
                    <select 
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        value={formData.hostId}
                        onChange={e => setFormData({...formData, hostId: e.target.value})}
                      >
                        <option value="">-- Chọn Host --</option>
                        {hosts.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                      </select>
                  </div>
                </div>
              </div>

              <hr className="border-gray-100" />

              {/* Script Source Selection */}
              <div>
                <label className="block text-sm font-bold text-gray-800 mb-3">Nguồn Kịch bản</label>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <button
                    onClick={() => setScriptSource('TEMPLATE')}
                    className={`flex flex-col items-center p-4 border rounded-xl transition ${
                      scriptSource === 'TEMPLATE' 
                        ? 'border-green-500 bg-green-50 ring-1 ring-green-500 text-green-700' 
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <svg className="w-8 h-8 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                    <span className="font-bold text-sm">Mẫu An Toàn Có Sẵn</span>
                    <span className="text-xs mt-1 opacity-80">Tối ưu cho từng loại BĐS</span>
                  </button>

                  <button
                    onClick={() => setScriptSource('AI')}
                    className={`flex flex-col items-center p-4 border rounded-xl transition ${
                      scriptSource === 'AI' 
                        ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500 text-brand-700' 
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <svg className="w-8 h-8 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    <span className="font-bold text-sm">Tạo Mới Bằng AI</span>
                    <span className="text-xs mt-1 opacity-80">Tùy chỉnh theo nhu cầu</span>
                  </button>
                </div>

                {scriptSource === 'TEMPLATE' ? (
                  <div className="bg-green-50 p-4 rounded-lg border border-green-100 animate-fade-in">
                    <label className="block text-sm font-medium text-green-800 mb-2">Chọn mẫu kịch bản:</label>
                    <select 
                      className="w-full border border-green-300 rounded-lg px-3 py-2 mb-2"
                      value={selectedTemplateId}
                      onChange={e => setSelectedTemplateId(e.target.value)}
                    >
                      {PREBUILT_TEMPLATES.map(t => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                    <p className="text-xs text-green-700 italic">
                      {PREBUILT_TEMPLATES.find(t => t.id === selectedTemplateId)?.description}
                    </p>
                  </div>
                ) : (
                  <div className="bg-brand-50 p-4 rounded-lg border border-brand-100 animate-fade-in space-y-3">
                     <div className="grid grid-cols-2 gap-4">
                       <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Thời lượng (phút)</label>
                        <input 
                          type="number" 
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={formData.durationMinutes}
                          onChange={e => setFormData({...formData, durationMinutes: parseInt(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Mục tiêu chính</label>
                         <select 
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={formData.objective}
                          onChange={e => setFormData({...formData, objective: e.target.value})}
                        >
                          {OBJECTIVES.map(o => <option key={o} value={o}>{o}</option>)}
                        </select>
                      </div>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Loại BĐS</label>
                        <select 
                          className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          value={formData.propertyType}
                          onChange={e => setFormData({...formData, propertyType: e.target.value})}
                        >
                          {PROPERTY_TYPES.map(p => <option key={p} value={p}>{p}</option>)}
                        </select>
                      </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className={`${scriptSource === 'TEMPLATE' ? 'bg-green-50 border-green-100' : 'bg-blue-50 border-blue-100'} p-4 rounded-lg border`}>
                <h4 className={`font-semibold ${scriptSource === 'TEMPLATE' ? 'text-green-900' : 'text-blue-900'} mb-2`}>
                  {scriptSource === 'TEMPLATE' ? 'Kịch bản Mẫu An Toàn (Đã kiểm duyệt)' : 'Kịch bản đề xuất bởi Gemini'}
                </h4>
                <div className="space-y-3">
                  {generatedBlocks.map((block, index) => (
                    <div key={index} className="bg-white p-3 rounded border border-gray-100 shadow-sm">
                      <div className="flex justify-between font-medium text-gray-800">
                        <span>{index + 1}. {block.title}</span>
                        <span className="text-gray-500 text-sm">{block.durationMinutes}p</span>
                      </div>
                      <ul className="mt-2 text-sm text-gray-600 list-disc list-inside">
                        {block.talkingPoints.slice(0, 3).map((tp, i) => (
                          <li key={i}>{tp}</li>
                        ))}
                      </ul>
                      {block.forbiddenCategoryIds.length > 0 && (
                        <div className="mt-2 text-xs text-red-500 flex items-center">
                          <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                          Lưu ý rủi ro: {block.forbiddenCategoryIds.join(", ")}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-3 bg-gray-50">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg"
          >
            Hủy
          </button>
          
          {step === 1 ? (
             <button 
             onClick={handleGenerateScript}
             disabled={isGenerating}
             className={`px-4 py-2 text-white rounded-lg disabled:opacity-50 flex items-center ${
               scriptSource === 'TEMPLATE' ? 'bg-green-600 hover:bg-green-700' : 'bg-brand-600 hover:bg-brand-700'
             }`}
           >
             {isGenerating ? (
               <>
                 <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                 AI đang viết...
               </>
             ) : (
                scriptSource === 'TEMPLATE' ? "Sử dụng Mẫu này" : "Tạo kịch bản với AI"
             )}
           </button>
          ) : (
            <button 
            onClick={handleSave}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-bold shadow-md"
          >
            Lưu & Lên lịch
          </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateSessionModal;