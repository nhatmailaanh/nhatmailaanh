import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../AppContext';
import { SessionStatus } from '../types';
import CreateSessionModal from './CreateSessionModal';

const SessionList: React.FC = () => {
  const { sessions, currentUser } = useAppContext();
  const navigate = useNavigate();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const getStatusColor = (status: SessionStatus) => {
    switch (status) {
      case SessionStatus.LIVE: return 'bg-red-100 text-red-700 border-red-200';
      case SessionStatus.DONE: return 'bg-gray-100 text-gray-700 border-gray-200';
      default: return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Quản lý Phiên Live</h1>
          <p className="text-gray-500">Xin chào, {currentUser.name}</p>
        </div>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="bg-brand-600 hover:bg-brand-700 text-white px-4 py-2 rounded-lg shadow-sm flex items-center transition"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Tạo Phiên Mới
        </button>
      </div>

      {sessions.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-100">
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900">Chưa có phiên live nào</h3>
          <p className="text-gray-500 mt-1">Bắt đầu bằng cách tạo một phiên mới và sử dụng AI để tạo kịch bản.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dự án</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thị trường</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mục tiêu</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Điểm an toàn</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Hành động</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sessions.map((session) => (
                <tr key={session.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{session.projectName}</div>
                    <div className="text-xs text-gray-500">{session.propertyType}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{session.market}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{session.objective}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full border ${getStatusColor(session.status)}`}>
                      {session.status === SessionStatus.PLANNED ? 'Sắp diễn ra' : 
                       session.status === SessionStatus.LIVE ? 'Đang Live' : 'Đã xong'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {session.safetyScore !== undefined ? (
                      <span className={`font-bold ${session.safetyScore < 80 ? 'text-red-600' : 'text-green-600'}`}>
                        {session.safetyScore}/100
                      </span>
                    ) : '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {session.status === SessionStatus.PLANNED && (
                      <button 
                        onClick={() => navigate(`/monitor/${session.id}`)}
                        className="text-brand-600 hover:text-brand-900 font-bold"
                      >
                        Vào Monitor
                      </button>
                    )}
                    {session.status === SessionStatus.LIVE && (
                      <button 
                        onClick={() => navigate(`/monitor/${session.id}`)}
                        className="text-red-600 hover:text-red-900 font-bold animate-pulse"
                      >
                        Tham gia Live
                      </button>
                    )}
                    {session.status === SessionStatus.DONE && (
                      <button 
                        onClick={() => navigate(`/report/${session.id}`)}
                        className="text-gray-600 hover:text-gray-900"
                      >
                        Xem Báo cáo
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {isCreateModalOpen && <CreateSessionModal onClose={() => setIsCreateModalOpen(false)} />}
    </div>
  );
};

export default SessionList;
