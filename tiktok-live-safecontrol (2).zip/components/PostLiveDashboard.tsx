import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { useAppContext } from '../AppContext';
import { FORBIDDEN_CATEGORIES } from '../constants';
import { Severity } from '../types';
import { generateTrainingRecommendations } from '../services/geminiService';

const PostLiveDashboard: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getSession, updateSession } = useAppContext();
  const session = getSession(id || '');
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  useEffect(() => {
    if (session && !session.aiTrainingRecommendations && session.violations.length > 0) {
      loadRecommendations();
    } else if (session?.aiTrainingRecommendations) {
      setRecommendations(session.aiTrainingRecommendations);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const loadRecommendations = async () => {
    if (!session) return;
    setIsLoadingAi(true);
    
    // Prepare summary string for AI
    const summary = session.violations.map(v => 
      `- Category: ${FORBIDDEN_CATEGORIES.find(c => c.id === v.categoryId)?.name}, Severity: ${v.severity}, Note: ${v.note}`
    ).join('\n');

    const res = await generateTrainingRecommendations(summary);
    setRecommendations(res.recommendations);
    
    // Save back to context
    updateSession(session.id, { aiTrainingRecommendations: res.recommendations });
    setIsLoadingAi(false);
  };

  if (!session) return <div>Loading...</div>;

  // Prepare Chart Data
  const severityData = [
    { name: 'Nhẹ', count: session.violations.filter(v => v.severity === Severity.LIGHT).length, color: '#fbbf24' },
    { name: 'TB', count: session.violations.filter(v => v.severity === Severity.MEDIUM).length, color: '#f97316' },
    { name: 'Nặng', count: session.violations.filter(v => v.severity === Severity.SEVERE).length, color: '#dc2626' },
  ];

  return (
    <div className="space-y-6">
      <button onClick={() => navigate('/')} className="text-gray-500 hover:text-gray-800 mb-4">&larr; Quay lại danh sách</button>
      
      <div className="flex justify-between items-end">
        <div>
           <h1 className="text-2xl font-bold text-gray-900">Báo cáo sau Live: {session.projectName}</h1>
           <p className="text-gray-500">Kết thúc lúc: {session.endedAt ? new Date(session.endedAt).toLocaleString() : 'N/A'}</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Điểm An Toàn Nội Dung</div>
          <div className={`text-4xl font-bold ${(session.safetyScore || 100) < 80 ? 'text-red-500' : 'text-green-500'}`}>
            {session.safetyScore || 100}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Chart Card */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="font-bold text-gray-800 mb-4">Phân bổ Vi phạm theo Mức độ</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={severityData}>
                <XAxis dataKey="name" />
                <YAxis allowDecimals={false} />
                <Tooltip cursor={{fill: 'transparent'}} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 text-center text-sm text-gray-500">
            Tổng số vi phạm: <span className="font-bold text-gray-900">{session.violations.length}</span>
          </div>
        </div>

        {/* AI Recommendations Card */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col">
          <div className="flex items-center gap-2 mb-4">
             <div className="p-2 bg-purple-100 rounded-lg">
               <svg className="w-5 h-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
             </div>
             <h3 className="font-bold text-gray-800">Đề xuất Training (AI Analysis)</h3>
          </div>
          
          <div className="flex-1">
            {isLoadingAi ? (
              <div className="flex items-center justify-center h-full text-gray-500 animate-pulse">
                Đang phân tích dữ liệu vi phạm...
              </div>
            ) : recommendations.length > 0 ? (
              <ul className="space-y-3">
                {recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start bg-purple-50 p-3 rounded-lg text-purple-900 text-sm">
                    <span className="font-bold mr-2">{i+1}.</span>
                    {rec}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-gray-400 text-sm text-center mt-10">
                Không có dữ liệu đủ để phân tích hoặc phiên live rất an toàn!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Violation Detail Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 font-bold text-gray-700">
          Chi tiết lỗi vi phạm
        </div>
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Thời gian</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Loại lỗi</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mức độ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Người nói</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ghi chú AI</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {session.violations.map(v => (
              <tr key={v.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(v.timestamp).toLocaleTimeString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {FORBIDDEN_CATEGORIES.find(c => c.id === v.categoryId)?.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                   <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      v.severity === Severity.SEVERE ? 'bg-red-100 text-red-800' : v.severity === Severity.MEDIUM ? 'bg-orange-100 text-orange-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {v.severity}
                    </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{v.speakerRole}</td>
                <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate" title={v.aiTrainingNote}>
                  {v.aiTrainingNote || '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PostLiveDashboard;
