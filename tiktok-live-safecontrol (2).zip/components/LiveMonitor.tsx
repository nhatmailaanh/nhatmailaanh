
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppContext } from '../AppContext';
import { FORBIDDEN_CATEGORIES } from '../constants';
import { SessionStatus, Severity } from '../types';
import ViolationModal from './ViolationModal';

const LiveMonitor: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getSession, updateSession, addViolation } = useAppContext();
  const session = getSession(id || '');
  const [activeBlockIndex, setActiveBlockIndex] = useState(0);
  const [isViolationModalOpen, setIsViolationModalOpen] = useState(false);
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    if (!session) return;
    let interval: ReturnType<typeof setInterval>;
    if (session.status === SessionStatus.LIVE) {
      interval = setInterval(() => setTimer(t => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [session?.status]);

  if (!session) return <div>Không tìm thấy phiên làm việc</div>;

  const currentBlock = session.blocks[activeBlockIndex];

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleStartSession = () => {
    updateSession(session.id, { 
      status: SessionStatus.LIVE,
      startedAt: new Date().toISOString()
    });
  };

  const handleEndSession = () => {
    if (window.confirm("Bạn có chắc chắn muốn kết thúc phiên live?")) {
      updateSession(session.id, { 
        status: SessionStatus.DONE,
        endedAt: new Date().toISOString()
      });
      navigate(`/report/${session.id}`);
    }
  };

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col">
      {/* Header Bar */}
      <div className="bg-white shadow-sm border-b px-6 py-3 flex justify-between items-center mb-4 rounded-lg">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="text-gray-500 hover:text-gray-800">
            &larr; Thoát
          </button>
          <div>
            <h1 className="font-bold text-gray-900">{session.projectName}</h1>
            <span className="text-xs text-gray-500">{session.propertyType} • {session.hostId}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="text-center">
            <div className="text-xs text-gray-500 uppercase">Thời gian Live</div>
            <div className={`font-mono text-xl font-bold ${session.status === SessionStatus.LIVE ? 'text-red-600' : 'text-gray-700'}`}>
              {formatTime(timer)}
            </div>
          </div>
          
          <div className="text-center">
            <div className="text-xs text-gray-500 uppercase">Điểm An Toàn</div>
            <div className={`font-bold text-xl ${(session.safetyScore || 100) < 80 ? 'text-red-500' : 'text-green-500'}`}>
              {session.safetyScore || 100}
            </div>
          </div>

          {session.status === SessionStatus.PLANNED && (
            <button onClick={handleStartSession} className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-bold shadow-md">
              Bắt đầu Live
            </button>
          )}
          {session.status === SessionStatus.LIVE && (
            <button onClick={handleEndSession} className="bg-gray-800 hover:bg-black text-white px-6 py-2 rounded-lg font-bold">
              Kết thúc
            </button>
          )}
        </div>
      </div>

      {/* Main 3-Column Layout */}
      <div className="flex-1 grid grid-cols-12 gap-4 min-h-0">
        
        {/* Left: Script Blocks Navigation */}
        <div className="col-span-3 bg-white rounded-lg shadow-sm border border-gray-200 overflow-y-auto flex flex-col">
          <div className="p-4 border-b border-gray-100 bg-gray-50 font-semibold text-gray-700">
            Dòng sự kiện (Script)
          </div>
          <div className="p-2 space-y-2">
            {session.blocks.map((block, idx) => (
              <div 
                key={block.id}
                onClick={() => setActiveBlockIndex(idx)}
                className={`p-3 rounded-lg cursor-pointer transition border ${
                  idx === activeBlockIndex 
                    ? 'bg-brand-50 border-brand-500 ring-1 ring-brand-500' 
                    : 'hover:bg-gray-50 border-transparent'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className={`text-sm font-bold ${idx === activeBlockIndex ? 'text-brand-700' : 'text-gray-700'}`}>
                    Phần {idx + 1}: {block.title}
                  </span>
                  <span className="text-xs bg-gray-200 px-1.5 py-0.5 rounded text-gray-600">{block.durationMinutes}p</span>
                </div>
                <div className="text-xs text-gray-500 truncate">
                  {block.talkingPoints[0]}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Middle: Active Block Details & Controls */}
        <div className="col-span-6 flex flex-col gap-4 min-h-0">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex-1 overflow-y-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">{currentBlock.title}</h2>
            
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Ý chính cần nói (Talking Points)</h3>
              <ul className="space-y-4">
                {currentBlock.talkingPoints.map((point, i) => (
                  <li key={i} className="flex items-start">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">{i+1}</span>
                    <div className="flex-1">
                      <span className="text-gray-900 font-medium leading-relaxed">{point}</span>
                      
                      {/* Detailed Teleprompter Text */}
                      {currentBlock.detailedScripts?.[i] && (
                        <div className="mt-2 p-3 bg-indigo-50 text-indigo-900 rounded-lg border border-indigo-100 text-sm leading-relaxed text-justify">
                          <span className="block font-bold text-xs uppercase text-indigo-500 mb-1">Lời thoại mẫu (Safe):</span>
                          {currentBlock.detailedScripts[i]}
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-6 p-4 bg-orange-50 rounded-lg border border-orange-100">
              <h3 className="text-sm font-bold text-orange-800 uppercase flex items-center mb-2">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                Rủi ro cao trong phần này
              </h3>
              <div className="flex flex-wrap gap-2">
                {currentBlock.forbiddenCategoryIds.map(catId => {
                  const cat = FORBIDDEN_CATEGORIES.find(c => c.id === catId);
                  return cat ? (
                    <span key={catId} className="px-2 py-1 bg-white border border-orange-200 text-orange-700 text-xs rounded shadow-sm">
                      {cat.name}
                    </span>
                  ) : null;
                })}
              </div>
            </div>
          </div>

          <button 
            onClick={() => setIsViolationModalOpen(true)}
            disabled={session.status !== SessionStatus.LIVE}
            className="bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-lg font-bold py-4 rounded-xl shadow-lg flex items-center justify-center transition transform hover:scale-[1.01]"
          >
            <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            BÁO CÁO VI PHẠM (LOG VIOLATION)
          </button>
        </div>

        {/* Right: Live Feed / Logs */}
        <div className="col-span-3 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col overflow-hidden">
           <div className="p-4 border-b border-gray-100 bg-gray-50 font-semibold text-gray-700 flex justify-between items-center">
            <span>Nhật ký Vi phạm</span>
            <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">{session.violations.length}</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-gray-50">
            {session.violations.length === 0 ? (
              <div className="text-center text-gray-400 text-sm mt-10 italic">Chưa có vi phạm nào.</div>
            ) : (
              [...session.violations].reverse().map(v => {
                const cat = FORBIDDEN_CATEGORIES.find(c => c.id === v.categoryId);
                return (
                  <div key={v.id} className="bg-white p-3 rounded shadow-sm border-l-4 border-red-500">
                    <div className="flex justify-between items-start">
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded text-white ${
                        v.severity === Severity.SEVERE ? 'bg-red-800' : v.severity === Severity.MEDIUM ? 'bg-orange-500' : 'bg-yellow-500'
                      }`}>
                        {v.severity}
                      </span>
                      <span className="text-xs text-gray-400">{new Date(v.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="mt-1 font-semibold text-sm text-gray-800">{cat?.name}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      <span className="font-medium text-gray-700">{v.speakerRole}:</span> {v.note || "No details"}
                    </div>
                    {v.aiRepairSuggestion && (
                      <div className="mt-2 pt-2 border-t border-gray-100">
                         <div className="text-[10px] font-bold text-green-600 uppercase mb-0.5">Sửa lỗi:</div>
                         <div className="text-xs text-gray-800 italic bg-green-50 p-1.5 rounded">"{v.aiRepairSuggestion}"</div>
                      </div>
                    )}
                  </div>
                )
              })
            )}
          </div>
        </div>

      </div>
      
      {isViolationModalOpen && (
        <ViolationModal 
          sessionId={session.id} 
          blockId={currentBlock.id} 
          onClose={() => setIsViolationModalOpen(false)}
          onSave={(v) => addViolation(session.id, v)}
        />
      )}
    </div>
  );
};

export default LiveMonitor;
